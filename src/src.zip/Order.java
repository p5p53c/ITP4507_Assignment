import java.util.Scanner;

public interface Order {
    public MenuOrder order(String name);
}
