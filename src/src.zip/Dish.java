import java.util.Scanner;

public interface Dish {
    public MenuItem create();
}
