import java.util.Vector;

public class MenuList {
    public Vector<MenuItem> menuList = new Vector<MenuItem>();
    public Vector<MenuOrder> orderList = new Vector<MenuOrder>();
}
